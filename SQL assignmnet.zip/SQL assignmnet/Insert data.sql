INSERT INTO Employee (EmpID, EmpName, Gender, Salary, Department, date_of_joining)
VALUES
(101, "Amit Sharma", "Male", 30000, "HR", 2022-01-15),
(102, "Neha Verma", "Female", 28000, "Finance", 2021-06-10),
(103, "Rohit Singh", "Male", 35000, "IT", 2020-09-25),
(104, "Pooja Patel", "Female", 26000, "Marketing", 2023-03-01),
(105, "Karan Mehta", "Male", 40000, "IT", 2019-11-18);