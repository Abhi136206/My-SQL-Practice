CREATE DATABASE IF NOT EXISTS officeDB;

USE officeDB;

CREATE TABLE Employee (
    EmpID INT AUTO_INCREMENT PRIMARY KEY,
    EmpName VARCHAR(100) NOT NULL,
    gender ENUM('Male', 'Female', 'Other'),
    salary DECIMAL(10, 2),
    Department VARCHAR(100) NOT NULL,
    date_of_joining DATE
);
