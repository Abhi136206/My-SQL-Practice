USE officeDB;
SHOW TABLES;

SELECT *FROM Employee;

-- Add column Email
ALTER TABLE Employee ADD Email VARCHAR(50);

-- Change size of EmpName
ALTER TABLE Employee MODIFY EmpName VARCHAR(60);

-- Drop column Email
ALTER TABLE Employee DROP COLUMN Email;

-- Truncate (removes all rows, keeps structure)
TRUNCATE TABLE Employee;

-- Drop (DO NOT EXECUTE)
-- DROP TABLE Employee;
-- Update salary of one employee
UPDATE Employee SET Salary = 32000 WHERE EmpID = 101;

-- Change department of an employee
UPDATE Employee SET Department = 'Admin' WHERE EmpID = 103;

-- Increase salary of all employees by 10%
UPDATE Employee SET Salary = Salary * 1.10;

-- Delete one employee using EmpID
DELETE FROM Employee WHERE EmpID = 105;

-- Delete employees from a specific department
DELETE FROM Employee WHERE Department = 'HR';

-- Delete all records
DELETE FROM Employee;

-- All employee records
SELECT * FROM Employee;

-- Employees from a particular department
SELECT * FROM Employee WHERE Department = 'IT';

-- Salary greater than 25000
SELECT * FROM Employee WHERE Salary > 25000;

-- Ascending order of EmpName
SELECT * FROM Employee ORDER BY EmpName ASC;