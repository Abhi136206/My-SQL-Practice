INSERT INTO Employeee
VALUES (106, NULL, 'Male', 45000, 'IT', '2024-01-15');
INSERT INTO Employeee
VALUES (101, 'Amit Sharma', 'Male', 50000, 'HR', '2022-01-15');
INSERT INTO Employeee
VALUES (101, 'Rahul Kumar', 'Male', 40000, 'IT', '2024-02-10');
INSERT INTO Employeee
VALUES (102, 'Neha Verma', 'Other', 45000, 'Finance', '2021-04-10');

INSERT INTO Employeee
(EmpID, EmpName, Gender, Salary, DOJ)
VALUES
(103, 'Rohit Singh', 'Male', 40000, '2020-09-25');

INSERT INTO Employeee
VALUES (104, 'Patel', 'Other', 35000, 'Marketing', '2023-03-01');

