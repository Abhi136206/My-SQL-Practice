USE OfficeDB;

SHOW TABLES;

DESCRIBE Department;

DESCRIBE Employee;

SHOW CREATE TABLE Employee;

SHOW CREATE TABLE Department;

SELECT e.EmpName, d.DeptName
FROM Employee AS e
INNER JOIN Department AS d
ON e.DeptID = d.DeptID;

SELECT e.*, d.DeptName
FROM Employee e
LEFT JOIN Department d
ON e.DeptID = d.DeptID;

SELECT e.EmpName, d.DeptName
FROM Employee e
RIGHT JOIN Department d
ON e.DeptID = d.DeptID;

SELECT e.EmpName, d.DeptName
FROM Employee e
FULL OUTER JOIN Department d
ON e.DeptID = d.DeptID;

SELECT e.EmpID, e.EmpName, e.Salary, d.DeptName
FROM Employee e
INNER JOIN Department d
ON e.DeptID = d.DeptID
WHERE d.DeptName = 'IT';

SELECT EmpID, EmpName, Salary, DeptID
FROM Employee

UNION

SELECT EmpID, EmpName, Salary, DeptID
FROM Employee_Old;

SELECT EmpID, EmpName, Salary, DeptID
FROM Employee

UNION ALL

SELECT EmpID, EmpName, Salary, DeptID
FROM Employee_Old;

SELECT EmpID, EmpName, Salary, DeptID
FROM Employee

INTERSECT

SELECT EmpID, EmpName, Salary, DeptID
FROM Employee_Old;

SELECT EmpID, EmpName, Salary, DeptID
FROM Employee

EXCEPT

SELECT EmpID, EmpName, Salary, DeptID
FROM Employee_Old;

SELECT *
FROM Employee
WHERE Salary > (
    SELECT AVG(Salary)
    FROM Employee
);

SELECT *
FROM Employee
WHERE DeptID = (
    SELECT DeptID
    FROM Department
    WHERE DeptName = 'IT'
);

SELECT *
FROM Employee
WHERE Salary = (
    SELECT MAX(Salary)
    FROM Employee
);

SELECT *
FROM Employee
WHERE Salary > (
    SELECT Salary
    FROM Employee
    WHERE EmpName = 'Neha Verma'
);

