INSERT INTO Department VALUES
(1, 'HR'),
(2, 'IT'),
(3, 'Finance'),
(4, 'Marketing'),
(5, 'Sales');

INSERT INTO Employee VALUES
(101, 'Neha Verma', 50000, 1),
(102, 'Rahul Sharma', 60000, 2),
(103, 'Amit Kumar', 45000, 3),
(104, 'Priya Singh', 70000, 2),
(105, 'Rohit Sharma', 40000, NULL);