CREATE TABLE Employee_Old (
    EmpID INT,
    EmpName VARCHAR(50),
    Salary DECIMAL(10, 2),
    DeptID INT
);

INSERT INTO Employee_Old VALUES
(101, 'Neha Verma', 50000, 1),
(102, 'Rahul Sharma', 60000, 2),
(106, 'Karan Singh', 55000, 3);