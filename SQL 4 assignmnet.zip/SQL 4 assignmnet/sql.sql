CREATE DATABASE IF NOT EXISTS OfficeDB;

USE OfficeDB;

CREATE TABLE Employe (
EmpID INT PRIMARY KEY,
EmpName VARCHAR(50) NOT NULL,
Department VARCHAR (50),
Salary DECIMAL (10,2),
DOJ date
);

INSERT INTO Employe (EmpID, EmpName, Department, Salary, DOJ) VALUES
(101, 'Amit Sharma', 'HR', 35000, '2020-09-25'),
(102, 'Neha Verma', 'Finance', 26000, '2023-03-01'),
(103, 'Rohit Singh', 'IT', 40000, '2019-11-18'),
(104, 'Pooja Patel', 'Marketing', 30000, '2022-01-15'),
(105, 'Karan Mehta', 'IT', 45000, '2021-06-10');

SELECT * FROM Employe

SELECT EmpName, Salary, ROW_NUMBER() OVER (ORDER BY Salary DESC) AS ROWNUM FROM Employe;

SELECT EmpName, Salary, RANK() OVER (ORDER BY Salary DESC) AS Salary FROM Employe;

SELECT EmpName, Salary, DENSE_RANK() OVER (ORDER BY Salary DESC) AS DENSERANK FROM Employe;

SELECT EmpName, Salary, Department, RANK() OVER (PARTITION BY Department ORDER BY Salary DESC) AS DepartmentRank FROM Employe;

SELECT EmpName, Salary, AVG(Salary) OVER() AS AverageSalary FROM Employe;

SELECT EmpName, Department, Salary, MAX(Salary) OVER (PARTITION BY Department) AS DepartmentMaxSalary FROM Employe;

WITH HighSalary AS (SELECT * FROM Employe WHERE Salary > 30000) 
SELECT * FROM HighSalary;

WITH IT_Employe AS (SELECT * FROM Employe WHERE Department = 'IT') SELECT * FROM IT_Employe;

WITH AverageSalary AS (SELECT AVG(Salary) AS AvgSalary FROM Employe)
SELECT e.* FROM Employe e CROSS JOIN AverageSalary a WHERE e.Salary>a.AvgSalary;

WITH EmployeData AS (SELECT * FROM Employe) SELECT * FROM EmployeData ORDER BY Salary DESC;

CREATE TABLE IF NOT EXISTS Employe_Audit (Emp INT, Action VARCHAR (20), ActionDate DATETIME);

DROP TRIGGER IF EXISTS after_employee_insert;

DELIMITER //

CREATE TRIGGER after_employee_insert
AFTER INSERT ON Employee
FOR EACH ROW
BEGIN
    INSERT INTO Employee_Audit
    VALUES (NEW.EmpID, 'INSERT', NOW());
END //

DELIMITER ;

DROP TRIGGER IF EXISTS after_employee_update;

DELIMITER //

CREATE TRIGGER after_employee_update
AFTER UPDATE ON Employee
FOR EACH ROW
BEGIN
    INSERT INTO Employee_Audit
    VALUES (NEW.EmpID, 'UPDATE', NOW());
END //

DELIMITER ;

DROP TRIGGER IF EXISTS prevent_it_employee_delete;

DELIMITER //

CREATE TRIGGER prevent_it_employee_delete
BEFORE DELETE ON Employee
FOR EACH ROW
BEGIN
    IF OLD.Department = 'IT' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Deletion of IT employees is not allowed';
    END IF;
END //

DELIMITER ;

INSERT INTO Employee
VALUES (106, 'Test Employee', 'HR', 32000, '2024-01-01');

UPDATE Employee
SET Salary = 33000
WHERE EmpID = 106;

DELETE FROM Employee
WHERE EmpID = 106;

DROP PROCEDURE IF EXISTS GetAllEmployees;

DELIMITER //

CREATE PROCEDURE GetAllEmployees()
BEGIN
    SELECT * FROM Employee;
END //

DELIMITER ;

CALL GetAllEmployees();

DROP PROCEDURE IF EXISTS GetEmployeesByDepartment;

DELIMITER //

CREATE PROCEDURE GetEmployeesByDepartment(
    IN dept_name VARCHAR(50)
)
BEGIN
    SELECT *
    FROM Employee
    WHERE Department = dept_name;
END //

DELIMITER ;

DROP PROCEDURE IF EXISTS IncreaseAllSalaries;

DELIMITER //

CREATE PROCEDURE IncreaseAllSalaries(
    IN increase_amount DECIMAL(10,2)
)
BEGIN
    UPDATE Employee
    SET Salary = Salary + increase_amount;
END //

DELIMITER ;

SET SQL_SAFE_UPDATES = 0
CALL IncreaseAllSalaries(1000);

DROP PROCEDURE IF EXISTS InsertEmployee;

DELIMITER //

CREATE PROCEDURE InsertEmployee(
    IN p_EmpID INT,
    IN p_EmpName VARCHAR(50),
    IN p_Department VARCHAR(50),
    IN p_Salary DECIMAL(10,2),
    IN p_DOJ DATE
)
BEGIN
    INSERT INTO Employee (
        EmpID,
        EmpName,
        Department,
        Salary,
        DOJ
    )
    VALUES (
        p_EmpID,
        p_EmpName,
        p_Department,
        p_Salary,
        p_DOJ
    );
END //

DELIMITER ;

CALL InsertEmployee(
    107,
    'Simran Kaur',
    'HR',
    38000,
    '2024-05-10'
);

CALL GetAllEmployees();

CALL GetEmployeesByDepartment('IT');

CALL IncreaseAllSalaries(500);

CALL InsertEmployee(
    108,
    'Arjun Singh',
    'Finance',
    42000,
    '2024-06-15'
);





